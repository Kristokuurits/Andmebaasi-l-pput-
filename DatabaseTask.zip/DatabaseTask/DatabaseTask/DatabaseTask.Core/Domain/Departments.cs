﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace DatabaseTask.Core.Domain
{
    public class Departments
    {
        [Key]
        public Guid Id { get; set; }
        public string Name { get; set; }
        public ICollection<Doctors> Doctors { get; set; } = new List<Doctors>();
    }
}
